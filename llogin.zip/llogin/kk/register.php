<!DOCKTYPE html>
<center><h1>STACK OVERFLOW<h1>
<h3>WEBSTER<h3><hr>
<html>
<head>
</head>
<body>
<h2>REGISTER HERE</h2>

<form action="submit.php" method="post">
<table>
<tr>
<td>Username<input type="text" name="username"/></td>
</tr>
<tr>
<td>password<input type="password" name="password"/></td>
</tr>
<tr>
<td>email<input type="email" name="email"/></td>
</tr>
<tr>
<td>college <input type="text" name="college"/></td>
</tr>
<tr>
<td><input type="submit" value="submit"/></td>
</form>
<form action="login.php" method="post">
<td><input type="submit" value="Already user? login"/></td>
</form>
</tr>
</center>
</table>

</body>
</html>