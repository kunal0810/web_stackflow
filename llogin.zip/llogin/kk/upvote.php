<?php
session_start();
header('location:http://localhost:8080/llogin/home.php');

?>